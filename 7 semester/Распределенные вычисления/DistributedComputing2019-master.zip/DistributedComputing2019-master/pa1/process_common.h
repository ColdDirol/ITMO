#ifndef __DC_PROCESS_COMMON__H
#define __DC_PROCESS_COMMON__H

#include "main.h"

void receive_all_done(ProcessContext context);

void receive_all_started(ProcessContext context);

#endif //__DC_PROCESS_COMMON__H
