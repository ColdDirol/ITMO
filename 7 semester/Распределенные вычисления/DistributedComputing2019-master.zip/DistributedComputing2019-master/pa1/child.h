#ifndef __DC_CHILD__H
#define __DC_CHILD__H

#include "main.h"

void child_work(ProcessContext context);

#endif // __DC_CHILD__H
