#include "banking.h"
#include "pa2345.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>

int pipes[MAX_PROCESS_ID + 1][MAX_PROCESS_ID + 1][2];
local_id self_id;
int proc_count;

static timestamp_t lamport_time = 0;

timestamp_t get_lamport_time(void)
{
    return lamport_time;
}

static void lamport_increment(void)
{
    lamport_time++;
}

static void lamport_update(timestamp_t received)
{
    if (received > lamport_time) lamport_time = received;
    lamport_time++;
}

int request_cs(const void * self)
{
    (void)self;
    return 0;
}

int release_cs(const void * self)
{
    (void)self;
    return 0;
}

typedef struct {
    local_id    id;
    balance_t   balance;
    BalanceHistory history;
    balance_t   pending_in;
} ProcessState;

static void set_header(Message * msg, MessageType type, uint16_t payload_len)
{
    msg->s_header.s_magic       = MESSAGE_MAGIC;
    msg->s_header.s_payload_len = payload_len;
    msg->s_header.s_type        = type;
    msg->s_header.s_local_time  = lamport_time;
}

static void record_history(ProcessState * ps, timestamp_t until)
{
    uint8_t cur = ps->history.s_history_len;
    while ((timestamp_t)cur <= until) {
        ps->history.s_history[cur].s_balance            = ps->balance;
        ps->history.s_history[cur].s_time               = (timestamp_t)cur;
        ps->history.s_history[cur].s_balance_pending_in = ps->pending_in;
        cur++;
    }
    ps->history.s_history_len = cur;
}

static void close_pipes_child(local_id id)
{
    for (int i = 0; i < proc_count; i++) {
        for (int j = 0; j < proc_count; j++) {
            if (i == j) continue;
            if (i == (int)id && j != (int)id) {
                close(pipes[i][j][0]);
            } else if (j == (int)id && i != (int)id) {
                close(pipes[i][j][1]);
            } else {
                close(pipes[i][j][0]);
                close(pipes[i][j][1]);
            }
        }
    }
}

static void close_pipes_parent(void)
{
    for (int i = 0; i < proc_count; i++) {
        for (int j = 0; j < proc_count; j++) {
            if (i == j) continue;
            if (i == PARENT_ID) {
                close(pipes[i][j][0]);
            } else if (j == PARENT_ID) {
                close(pipes[i][j][1]);
            } else {
                close(pipes[i][j][0]);
                close(pipes[i][j][1]);
            }
        }
    }
}

static void handle_transfer(ProcessState * ps, Message * in, FILE * fevents,
    char * buf)
{
    int len;
    TransferOrder order;
    memcpy(&order, in->s_payload, sizeof(TransferOrder));

    if (order.s_src == ps->id) {
        record_history(ps, lamport_time);
        ps->balance -= order.s_amount;
        ps->pending_in += order.s_amount;

        len = snprintf(buf, 256, log_transfer_out_fmt,
            (int)lamport_time, (int)ps->id, (int)order.s_amount, (int)order.s_dst);
        fwrite(buf, 1, (size_t)len, fevents);
        fflush(fevents);
        print(buf);

        lamport_increment();
        Message fwd;
        memcpy(fwd.s_payload, &order, sizeof(TransferOrder));
        set_header(&fwd, TRANSFER, sizeof(TransferOrder));
        send(ps, order.s_dst, &fwd);

        record_history(ps, lamport_time);
    } else if (order.s_dst == ps->id) {
        record_history(ps, lamport_time);
        ps->balance += order.s_amount;
        ps->pending_in -= order.s_amount;

        len = snprintf(buf, 256, log_transfer_in_fmt,
            (int)lamport_time, (int)ps->id, (int)order.s_amount, (int)order.s_src);
        fwrite(buf, 1, (size_t)len, fevents);
        fflush(fevents);
        print(buf);

        lamport_increment();
        Message ack;
        set_header(&ack, ACK, 0);
        send(ps, PARENT_ID, &ack);

        record_history(ps, lamport_time);
    }
}

static void child_process(ProcessState * ps, FILE * fevents)
{
    int need = proc_count - 2;
    char buf[256];
    int len;

    Message deferred[MAX_PROCESS_ID + 1];
    int deferred_count = 0;

    lamport_increment();
    len = snprintf(buf, sizeof(buf), log_started_fmt,
        (int)lamport_time, (int)ps->id, (int)getpid(), (int)getppid(), (int)ps->balance);
    fwrite(buf, 1, (size_t)len, fevents);
    fflush(fevents);
    print(buf);

    Message msg;
    set_header(&msg, STARTED, (uint16_t)len);
    memcpy(msg.s_payload, buf, (size_t)len);
    send_multicast(ps, &msg);

    int started = 0;
    while (started < need) {
        Message in;
        receive_any(ps, &in);
        lamport_update(in.s_header.s_local_time);
        if (in.s_header.s_type == STARTED) {
            started++;
        } else {
            deferred[deferred_count++] = in;
        }
    }

    len = snprintf(buf, sizeof(buf), log_received_all_started_fmt,
        (int)lamport_time, (int)ps->id);
    fwrite(buf, 1, (size_t)len, fevents);
    fflush(fevents);
    print(buf);

    record_history(ps, lamport_time);

    int running = 1;
    int di = 0;

    while (running) {
        Message in;
        if (di < deferred_count) {
            in = deferred[di++];
            lamport_update(in.s_header.s_local_time);
        } else {
            receive_any(ps, &in);
            lamport_update(in.s_header.s_local_time);
        }

        if (in.s_header.s_type == STOP) {
            running = 0;
        } else if (in.s_header.s_type == TRANSFER) {
            handle_transfer(ps, &in, fevents, buf);
        }
    }

    lamport_increment();
    len = snprintf(buf, sizeof(buf), log_done_fmt,
        (int)lamport_time, (int)ps->id, (int)ps->balance);
    fwrite(buf, 1, (size_t)len, fevents);
    fflush(fevents);
    print(buf);

    Message done_msg;
    set_header(&done_msg, DONE, (uint16_t)len);
    memcpy(done_msg.s_payload, buf, (size_t)len);
    send_multicast(ps, &done_msg);

    record_history(ps, lamport_time);

    int done = 0;
    while (done < need) {
        Message in;
        receive_any(ps, &in);
        lamport_update(in.s_header.s_local_time);
        if (in.s_header.s_type == DONE) done++;
    }

    len = snprintf(buf, sizeof(buf), log_received_all_done_fmt,
        (int)lamport_time, (int)ps->id);
    fwrite(buf, 1, (size_t)len, fevents);
    fflush(fevents);
    print(buf);

    record_history(ps, lamport_time);

    ps->history.s_id = ps->id;

    lamport_increment();
    size_t hist_size = sizeof(local_id) + sizeof(uint8_t)
        + ps->history.s_history_len * sizeof(BalanceState);
    Message hist_msg;
    memcpy(hist_msg.s_payload, &ps->history, hist_size);
    set_header(&hist_msg, BALANCE_HISTORY, (uint16_t)hist_size);
    send(ps, PARENT_ID, &hist_msg);
}

void transfer(void * parent_data, local_id src, local_id dst, balance_t amount)
{
    TransferOrder order;
    order.s_src    = src;
    order.s_dst    = dst;
    order.s_amount = amount;

    lamport_increment();
    Message msg;
    memcpy(msg.s_payload, &order, sizeof(TransferOrder));
    set_header(&msg, TRANSFER, sizeof(TransferOrder));
    send(parent_data, src, &msg);

    Message ack;
    receive(parent_data, dst, &ack);
    lamport_update(ack.s_header.s_local_time);
}

int main(int argc, char * argv[])
{
    if (argc < 3) return 1;

    int num_children = atoi(argv[2]);
    if (num_children < 1 || num_children > MAX_PROCESS_ID) return 1;
    if (argc < 3 + num_children) return 1;

    proc_count = num_children + 1;

    for (int i = 0; i < proc_count; i++) {
        for (int j = 0; j < proc_count; j++) {
            if (i != j) {
                if (pipe(pipes[i][j]) < 0) return 1;
                int flags0 = fcntl(pipes[i][j][0], F_GETFL, 0);
                fcntl(pipes[i][j][0], F_SETFL, flags0 | O_NONBLOCK);
                int flags1 = fcntl(pipes[i][j][1], F_GETFL, 0);
                fcntl(pipes[i][j][1], F_SETFL, flags1 | O_NONBLOCK);
            }
        }
    }

    FILE * fpipes = fopen(pipes_log, "w");
    for (int i = 0; i < proc_count; i++) {
        for (int j = 0; j < proc_count; j++) {
            if (i != j) {
                fprintf(fpipes, "pipe %d->%d: read_fd=%d write_fd=%d\n",
                    i, j, pipes[i][j][0], pipes[i][j][1]);
            }
        }
    }
    fclose(fpipes);

    FILE * fevents = fopen(events_log, "a");

    balance_t balances[MAX_PROCESS_ID + 1];
    for (int i = 1; i <= num_children; i++) {
        balances[i] = (balance_t)atoi(argv[2 + i]);
    }

    for (int child = 1; child <= num_children; child++) {
        pid_t pid = fork();
        if (pid < 0) return 1;
        if (pid == 0) {
            self_id = (local_id)child;
            close_pipes_child(self_id);

            ProcessState ps;
            memset(&ps, 0, sizeof(ps));
            ps.id      = self_id;
            ps.balance = balances[self_id];
            ps.history.s_id          = self_id;
            ps.history.s_history_len = 0;
            ps.pending_in            = 0;

            child_process(&ps, fevents);
            fclose(fevents);
            exit(0);
        }
    }

    self_id = PARENT_ID;
    close_pipes_parent();

    int started = 0;
    while (started < num_children) {
        Message in;
        receive_any(NULL, &in);
        lamport_update(in.s_header.s_local_time);
        if (in.s_header.s_type == STARTED) started++;
    }

    char buf[256];
    int len = snprintf(buf, sizeof(buf), log_received_all_started_fmt,
        (int)lamport_time, (int)PARENT_ID);
    fwrite(buf, 1, (size_t)len, fevents);
    fflush(fevents);

    bank_robbery(NULL, (local_id)num_children);

    lamport_increment();
    Message stop_msg;
    set_header(&stop_msg, STOP, 0);
    send_multicast(NULL, &stop_msg);

    int done = 0;
    while (done < num_children) {
        Message in;
        receive_any(NULL, &in);
        lamport_update(in.s_header.s_local_time);
        if (in.s_header.s_type == DONE) done++;
    }

    AllHistory all;
    all.s_history_len = (uint8_t)num_children;
    int hist_received = 0;
    while (hist_received < num_children) {
        Message in;
        receive_any(NULL, &in);
        lamport_update(in.s_header.s_local_time);
        if (in.s_header.s_type == BALANCE_HISTORY) {
            BalanceHistory * bh = (BalanceHistory *)in.s_payload;
            int idx = bh->s_id - 1;
            memcpy(&all.s_history[idx], in.s_payload,
                sizeof(local_id) + sizeof(uint8_t)
                + bh->s_history_len * sizeof(BalanceState));
            hist_received++;
        }
    }

    fclose(fevents);
    print_history(&all);

    for (int i = 0; i < num_children; i++) wait(NULL);

    return 0;
}
