#include "ipc.h"
#include <unistd.h>
#include <errno.h>
#include <sys/select.h>

extern int pipes[MAX_PROCESS_ID + 1][MAX_PROCESS_ID + 1][2];
extern local_id self_id;
extern int proc_count;

int send(void * self, local_id dst, const Message * msg)
{
    (void)self;
    int fd = pipes[self_id][dst][1];
    size_t total = sizeof(MessageHeader) + msg->s_header.s_payload_len;
    const char * ptr = (const char *)msg;
    size_t done = 0;
    while (done < total) {
        ssize_t n = write(fd, ptr + done, total - done);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        done += (size_t)n;
    }
    return 0;
}

int send_multicast(void * self, const Message * msg)
{
    for (int i = 0; i < proc_count; i++) {
        if (i == self_id) continue;
        if (send(self, (local_id)i, msg) != 0) return -1;
    }
    return 0;
}

static int read_exact(int fd, char * buf, size_t size)
{
    size_t done = 0;
    while (done < size) {
        ssize_t n = read(fd, buf + done, size - done);
        if (n < 0) {
            if (errno == EINTR || errno == EAGAIN) continue;
            return -1;
        }
        if (n == 0) return -1;
        done += (size_t)n;
    }
    return 0;
}

int receive(void * self, local_id from, Message * msg)
{
    (void)self;
    int fd = pipes[from][self_id][0];
    if (read_exact(fd, (char *)msg, sizeof(MessageHeader)) != 0) return -1;
    if (read_exact(fd, msg->s_payload, msg->s_header.s_payload_len) != 0) return -1;
    return 0;
}

int receive_any(void * self, Message * msg)
{
    while (1) {
        fd_set rfds;
        FD_ZERO(&rfds);
        int maxfd = 0;
        for (int i = 0; i < proc_count; i++) {
            if (i == self_id) continue;
            int fd = pipes[i][self_id][0];
            FD_SET(fd, &rfds);
            if (fd > maxfd) maxfd = fd;
        }
        int r = select(maxfd + 1, &rfds, NULL, NULL, NULL);
        if (r < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        for (int i = 0; i < proc_count; i++) {
            if (i == self_id) continue;
            int fd = pipes[i][self_id][0];
            if (FD_ISSET(fd, &rfds)) {
                if (read_exact(fd, (char *)msg, sizeof(MessageHeader)) != 0) continue;
                if (read_exact(fd, msg->s_payload, msg->s_header.s_payload_len) != 0) return -1;
                return 0;
            }
        }
    }
}
