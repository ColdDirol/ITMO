#include "parent.h"
#include "util.h"
#include <string.h>

static int await_child_response(void* comm_channel, int child_id, BalanceHistory** history_ptr) {
    Message response_msg;

    while (receive(comm_channel, child_id, &response_msg) != 0) {
    }

    if (response_msg.s_header.s_type == BALANCE_HISTORY) {
        *history_ptr = (BalanceHistory*)response_msg.s_payload;
        return 1;
    }

    return 0;
}

static void initialize_result_storage(AllHistory* storage) {
    memset(storage, 0, sizeof(AllHistory));
    storage->s_history_len = 0;
}

static void store_child_record(AllHistory* storage, BalanceHistory* child_record) {
    if (storage->s_history_len < MAX_PROCESS_ID + 1) {
        storage->s_history[storage->s_history_len] = *child_record;
        storage->s_history_len++;
    }
}

void gather_child_balance_records(void* communication_channel, int child_count, AllHistory* result_storage) {
    initialize_result_storage(result_storage);

    BalanceHistory* child_data;

    for (int current_child = 1; current_child <= child_count; current_child++) {
        if (await_child_response(communication_channel, current_child, &child_data)) {
            store_child_record(result_storage, child_data);
        }
    }
}
