#include "ipc.h"
#include "util.h"
#include <unistd.h>
#include <string.h>
#include <errno.h>

static int perform_nonblocking_read(int fd, char* data_buffer, size_t bytes_required) {
    size_t bytes_obtained = 0;
    ssize_t read_result;

    while (bytes_obtained < bytes_required) {
        read_result = read(fd, data_buffer + bytes_obtained, bytes_required - bytes_obtained);

        if (read_result == 0) {
            break;
        }

        if (read_result < 0) {
            if (errno == EAGAIN) {
                if (bytes_obtained == 0) {
                    return -1;
                }
                break;
            }
            return -1;
        }

        bytes_obtained += read_result;
    }

    return bytes_obtained;
}

static int perform_nonblocking_write(int fd, const char* data_buffer, size_t bytes_to_send) {
    size_t bytes_transferred = 0;
    ssize_t write_result;

    while (bytes_transferred < bytes_to_send) {
        write_result = write(fd, data_buffer + bytes_transferred, bytes_to_send - bytes_transferred);

        if (write_result < 0) {
            if (errno == EAGAIN) {
                if (bytes_transferred == 0) {
                    return -1;
                }
                break;
            }
            return -1;
        }

        bytes_transferred += write_result;
    }

    return bytes_transferred;
}

int send(void* communication_context, local_id destination, const Message* message_packet) {
    int*** pipe_network = (int***)communication_context;
    int output_fd = pipe_network[destination][PROCESS_ID][1];

    size_t complete_message_size = sizeof(MessageHeader) + message_packet->s_header.s_payload_len;
    const char* raw_message_data = (const char*)message_packet;

    int transfer_result = perform_nonblocking_write(output_fd, raw_message_data, complete_message_size);
    return (transfer_result == complete_message_size) ? 0 : -1;
}

int receive(void* communication_context, local_id source, Message* message_buffer) {
    int*** pipe_network = (int***)communication_context;
    int input_fd = pipe_network[PROCESS_ID][source][0];

    int header_bytes = perform_nonblocking_read(input_fd, (char*)&message_buffer->s_header, sizeof(MessageHeader));
    if (header_bytes <= 0) {
        return -1;
    }

    uint16_t payload_size = message_buffer->s_header.s_payload_len;
    if (payload_size > 0) {
        int payload_bytes = perform_nonblocking_read(input_fd, message_buffer->s_payload, payload_size);
        if (payload_bytes <= 0) {
            return -1;
        }
    }

    return 0;
}

int send_multicast(void* communication_context, const Message* message_packet) {
    int*** pipe_network = (int***)communication_context;
    int successful_transmissions = 0;
    int delivery_status[P_COUNT + 1];

    for (int i = 0; i <= P_COUNT; i++) {
        delivery_status[i] = 0;
    }

    while (successful_transmissions < P_COUNT) {
        for (int target_id = 0; target_id <= P_COUNT; target_id++) {
            if (target_id != PROCESS_ID && !delivery_status[target_id]) {
                if (send(pipe_network, target_id, message_packet) == 0) {
                    delivery_status[target_id] = 1;
                    successful_transmissions++;
                }
            }
        }
    }

    return 0;
}

int receive_any(void* communication_context, Message* message_buffer) {
    for (int potential_source = 0; potential_source <= P_COUNT; potential_source++) {
        if (potential_source != PROCESS_ID) {
            if (receive(communication_context, potential_source, message_buffer) == 0) {
                return 0;
            }
        }
    }
    return -1;
}
