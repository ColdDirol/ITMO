#ifndef __IFMO_DISTRIBUTED_CLASS_CHILD__H
#define __IFMO_DISTRIBUTED_CLASS_CHILD__H

#include <unistd.h>
#include <sys/types.h>
#include "banking.h"
#include "pa2345.h"

typedef struct {
    BalanceHistory history;
    balance_t current_amount;
    int process_count;
} ChildContext;

void child_process_entry(int*** pipes_table, int process_count, balance_t initial_balance);

#endif
