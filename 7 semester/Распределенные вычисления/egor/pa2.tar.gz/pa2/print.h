#ifndef __IFMO_DISTRIBUTED_CLASS_PRINT__H
#define __IFMO_DISTRIBUTED_CLASS_PRINT__H

#include "banking.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void print_history_1(const AllHistory* history);

#endif

#include <errno.h>
#include <stdio.h>
#include "banking.h"
#include <stdlib.h>
#include <string.h>

void print_history_1(const AllHistory* history)
{
    if (history == NULL)
    {
        fprintf(stderr, "print_history: history is NULL!\n");
        exit(1);
    }

    typedef struct
    {
        int balance;
        int pending;
    } BalanceEntry;

    int max_time = 0;
    int has_pending = 0;
    int rows = history->s_history_len + 2;
    BalanceEntry table[rows][MAX_T];
    memset(table, 0, sizeof(table));

    for (int i = 0; i < history->s_history_len; ++i)
    {
        for (int j = 0; j < history->s_history[i].s_history_len; ++j)
        {
            const BalanceState* state = &history->s_history[i].s_history[j];
            int id = history->s_history[i].s_id;
            table[id][state->s_time].balance = state->s_balance;
            table[id][state->s_time].pending = state->s_balance_pending_in;
            if (max_time < state->s_time)
            {
                max_time = state->s_time;
            }
            if (state->s_balance_pending_in > 0)
            {
                has_pending = 1;
            }
        }
    }
    if (max_time > MAX_T)
    {
        fprintf(stderr, "print_history: max time: %d, expected < %d!\n",
            max_time, MAX_T);
        return;
    }

    for (int j = 0; j <= max_time; ++j)
    {
        int total = 0;
        for (int i = 1; i <= history->s_history_len; ++i)
        {
            total += table[i][j].balance + table[i][j].pending;
        }
        table[rows - 1][j].balance = total;
        table[rows - 1][j].pending = 0;
    }

    fflush(stderr);
    fflush(stdout);

    const char* cell_format_pending = " %d (%d) ";
    const char* cell_format = " %d ";

    char buffer[128];
    int max_width = 0;
    for (int i = 1; i <= history->s_history_len; ++i)
    {
        for (int j = 0; j <= max_time; ++j)
        {
            if (has_pending)
            {
                sprintf(buffer, cell_format_pending, table[i][j].balance, table[i][j].pending);
            }
            else
            {
                sprintf(buffer, cell_format, table[i][j].balance);
            }
            int width = strlen(buffer);
            if (max_width < width)
            {
                max_width = width;
            }
        }
    }

    const char* header = "Proc \\ time |";
    const int header_width = strlen(header);
    const int line_length = (header_width + 1) + (max_width + 1) * (max_time + 1);

    char line[line_length + 2];
    for (int i = 0; i < line_length; ++i)
    {
        line[i] = '-';
    }
    line[line_length] = '\n';
    line[line_length + 1] = '\0';

    if (has_pending)
    {
        printf("\nBalance history for time [0;%d], $balance ($pending):\n", max_time);
    }
    else
    {
        printf("\nBalance history for time [0;%d], $balance:\n", max_time);
    }
    printf("%s\n", line);

    printf("%s ", header);
    for (int j = 0; j <= max_time; ++j)
    {
        printf("%*d |", max_width - 1, j);
    }
    printf("\n");
    printf("%s\n", line);

    for (int i = 1; i <= history->s_history_len; ++i)
    {
        printf("%11d | ", i);
        for (int j = 0; j <= max_time; ++j)
        {
            if (has_pending)
            {
                sprintf(buffer, cell_format_pending, table[i][j].balance, table[i][j].pending);
            }
            else
            {
                sprintf(buffer, cell_format, table[i][j].balance);
            }
            printf("%*s|", max_width, buffer);
        }
        printf("\n");
        printf("%s\n", line);
    }

    printf("      Total | ");
    for (int j = 0; j <= max_time; ++j)
    {
        printf("%*d |", max_width - 1, table[rows - 1][j].balance);
    }
    printf("\n");
    printf("%s\n", line);
}
