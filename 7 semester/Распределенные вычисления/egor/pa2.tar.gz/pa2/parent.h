#ifndef __IFMO_DISTRIBUTED_CLASS_PARENT__H
#define __IFMO_DISTRIBUTED_CLASS_PARENT__H

#include "util.h"
#include "ipc.h"

typedef struct {
    AllHistory collected_data;
    int processes_remaining;
} HistoryCollector;

void gather_child_balance_records(void* communication_channel, int child_count, AllHistory* result_storage);

#endif
