#ifndef __IFMO_DISTRIBUTED_CLASS_UTIL__H
#define __IFMO_DISTRIBUTED_CLASS_UTIL__H
#define _POSIX_C_SOURCE 200809L

#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include "ipc.h"
#include <stdarg.h>
#include "pa2345.h"
#include "banking.h"
#include <sys/wait.h>

extern int PROCESS_ID;
extern int P_COUNT;
extern pid_t parent_pid;
extern pid_t curr_pid;
extern int next_id;
extern int pipes_log_fd;
extern int events_log_fd;
extern balance_t* balances;
extern int*** pipes;

int read_process_count(int argc, char* argv[]);
void get_balance_arr(int argc, char* argv[], balance_t* balances);
int create_pipes(int n);
void close_unused_pipes(int*** pipes);
int free_pipes(int n);
void err(const char* msg);

Message* create_msg(MessageType msg_type, void* buf, int len);
int receive_all(void* self, int start_pid, int end_pid, uint16_t msg_type);
int send_empty_msg(void* self, int dst_pid, MessageType type);

int get_string_by_template(char** buf, const char* template, ...);
void log_event(const char* buf, size_t len);
void log_all_started(timestamp_t timestamp, int pid);
void log_all_done(timestamp_t timestamp, int pid);
void log_started_pid(timestamp_t timestamp, int p_number, int pid, int ppid, balance_t balance);
void log_transfer_in(timestamp_t timestamp, int sender, int receiver, balance_t amount);
void log_transfer_out(timestamp_t timestamp, int sender, int receiver, balance_t amount);
int log_pipes(int n, const char* pipes_log);

void child_process_entry(int*** pipes_table, int process_count, balance_t initial_balance);
void gather_child_balance_records(void* communication_channel, int child_count, AllHistory* result_storage);

#endif
