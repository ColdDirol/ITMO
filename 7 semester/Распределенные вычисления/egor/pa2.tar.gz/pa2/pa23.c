#include "common.h"
#include "ipc.h"
#include "util.h"
#include "parent.h"
#include "child.h"

int PROCESS_ID = 0;
pid_t curr_pid = 0;
int P_COUNT = 0;
pid_t parent_pid = 0;
int next_id = 1;
int pipes_log_fd = 0;
int events_log_fd = 0;
balance_t* balances = NULL;
int*** pipes = NULL;

void create_child(int process_count) {
    pid_t pid = fork();
    switch (pid) {
    case -1:
        err("fork");
        exit(EXIT_FAILURE);
    case 0:
        PROCESS_ID = next_id;
        curr_pid = getpid();
        parent_pid = getppid();
        child_process_entry(pipes, process_count, balances[PROCESS_ID]);
        exit(0);
    default:
        next_id++;
    }
}

void parent_main(int*** pipes, int process_count) {
    AllHistory all_history;
    Message* msg;

    close_unused_pipes(pipes);
    receive_all(pipes, 1, P_COUNT, STARTED);

    bank_robbery(pipes, P_COUNT);

    msg = create_msg(STOP, NULL, 0);
    send_multicast(pipes, msg);
    free(msg);

    receive_all(pipes, 1, P_COUNT, DONE);

    gather_child_balance_records(pipes, P_COUNT, &all_history);

    while (wait(NULL) > 0);

    print_history(&all_history);
}

int main(int argc, char* argv[]) {
    int n = read_process_count(argc, argv);
    if (n < 1) {
        err("Process count must be positive");
    }

    balances = malloc(sizeof(balance_t) * (n + 1));
    get_balance_arr(argc, argv, balances);

    events_log_fd = open(events_log, O_WRONLY | O_CREAT | O_APPEND, 0644);
    pipes_log_fd = open(pipes_log, O_WRONLY | O_CREAT | O_APPEND, 0644);

    P_COUNT = n;
    create_pipes(n);
    log_pipes(n + 1, pipes_log);

    curr_pid = getpid();
    for (int i = 0; i < n; i++) {
        create_child(n);
    }

    parent_main(pipes, n);
    return 0;
}
