#include "child.h"
#include "ipc.h"
#include "util.h"

static void save_balance_snapshot(BalanceHistory* history_log, timestamp_t moment, balance_t amount) {
    if (history_log->s_history_len >= MAX_T) return;

    BalanceState snapshot;
    snapshot.s_balance = amount;
    snapshot.s_time = moment;
    snapshot.s_balance_pending_in = 0;

    history_log->s_history[history_log->s_history_len] = snapshot;
    history_log->s_history_len++;
}

static void interpolate_missing_times(BalanceHistory* history_log, timestamp_t current_moment, balance_t current_amount) {
    if (history_log->s_history_len == 0) {
        save_balance_snapshot(history_log, current_moment, current_amount);
        return;
    }

    BalanceState previous = history_log->s_history[history_log->s_history_len - 1];

    for (timestamp_t missing_time = previous.s_time + 1; missing_time < current_moment; missing_time++) {
        save_balance_snapshot(history_log, missing_time, previous.s_balance);
    }

    if (current_moment > previous.s_time) {
        save_balance_snapshot(history_log, current_moment, current_amount);
    }
}

static int process_message_queue(BalanceHistory* history_log, balance_t* amount_ptr, int sender_id) {
    Message incoming;

    if (receive(pipes, sender_id, &incoming) != 0) {
        return -1;
    }

    if (incoming.s_header.s_type == TRANSFER) {
        TransferOrder* transaction = (TransferOrder*)incoming.s_payload;
        timestamp_t event_moment = get_physical_time();

        if (transaction->s_src == PROCESS_ID) {
            send(pipes, transaction->s_dst, &incoming);
            *amount_ptr -= transaction->s_amount;
            log_transfer_out(event_moment, transaction->s_src, transaction->s_dst, transaction->s_amount);
        }
        else {
            send_empty_msg(pipes, PARENT_ID, ACK);
            *amount_ptr += transaction->s_amount;
            log_transfer_in(event_moment, transaction->s_dst, transaction->s_amount, transaction->s_src);
        }

        interpolate_missing_times(history_log, event_moment, *amount_ptr);
        return 0;
    }

    if (sender_id == PARENT_ID && incoming.s_header.s_type == STOP) {
        return 1;
    }

    return -1;
}

static void initialize_child_environment(int*** pipes_table, int process_count) {
    pipes = pipes_table;
    P_COUNT = process_count;
    close_unused_pipes(pipes);
}

static void broadcast_start_message(balance_t initial_balance) {
    char* message_text;
    int text_length = get_string_by_template(&message_text, log_started_fmt,
        get_physical_time(), PROCESS_ID,
        curr_pid, parent_pid, initial_balance);

    Message* start_message = create_msg(STARTED, message_text, text_length);
    send_multicast(pipes, start_message);
    free(start_message);
    free(message_text);
}

static void broadcast_completion_message(balance_t final_balance) {
    char* completion_text;
    int text_length = get_string_by_template(&completion_text, log_done_fmt,
        get_physical_time(), PROCESS_ID, final_balance);

    Message* done_message = create_msg(DONE, completion_text, text_length);
    send_multicast(pipes, done_message);
    free(done_message);
    free(completion_text);
}

static void send_history_to_parent(BalanceHistory* history_log) {
    Message* history_message = create_msg(BALANCE_HISTORY, history_log,
        sizeof(history_log->s_id) + sizeof(history_log->s_history_len) +
        history_log->s_history_len * sizeof(BalanceState));

    while (send(pipes, PARENT_ID, history_message) != 0);
    free(history_message);
}

void child_process_entry(int*** pipes_table, int process_count, balance_t initial_balance) {
    initialize_child_environment(pipes_table, process_count);

    BalanceHistory account_history;
    account_history.s_id = PROCESS_ID;
    account_history.s_history_len = 0;

    save_balance_snapshot(&account_history, get_physical_time(), initial_balance);
    log_started_pid(get_physical_time(), PROCESS_ID, getpid(), getppid(), initial_balance);

    broadcast_start_message(initial_balance);
    receive_all(pipes, 1, process_count, STARTED);

    balance_t working_balance = initial_balance;
    int current_source = 0;
    int should_terminate = 0;

    while (!should_terminate) {
        if (current_source != PROCESS_ID) {
            int result = process_message_queue(&account_history, &working_balance, current_source);
            if (result == 1) {
                should_terminate = 1;
            }
        }
        current_source = (current_source + 1) % (process_count + 1);
    }

    broadcast_completion_message(working_balance);
    receive_all(pipes, 1, process_count, DONE);

    interpolate_missing_times(&account_history, get_physical_time(), working_balance);
    send_history_to_parent(&account_history);
}
