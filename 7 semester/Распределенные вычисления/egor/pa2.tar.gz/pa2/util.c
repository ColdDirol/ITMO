#include "util.h"

void err(const char* msg) {
    printf("Error: %s\n", msg);
}

Message* create_msg(MessageType msg_type, void* buf, int len) {
    Message* msg = malloc(sizeof(Message));
    msg->s_header.s_magic = MESSAGE_MAGIC;
    msg->s_header.s_type = msg_type;
    msg->s_header.s_local_time = get_physical_time();
    msg->s_header.s_payload_len = len;
    if (len > 0)
        memcpy(msg->s_payload, buf, len);
    return msg;
}

int send_empty_msg(void* self, int dst_pid, MessageType type) {
    Message* msg = create_msg(type, NULL, 0);
    int result = send(self, dst_pid, msg);
    free(msg);
    return result;
}

void transfer(void* parent_data, local_id src, local_id dst, balance_t amount) {
    TransferOrder order;
    order.s_src = src;
    order.s_dst = dst;
    order.s_amount = amount;

    Message* msg = create_msg(TRANSFER, &order, sizeof(TransferOrder));

    while (send(parent_data, src, msg) != 0);

    while (receive(pipes, dst, msg) != 0);

    free(msg);
}

int get_string_by_template(char** buf, const char* template, ...) {
    va_list args;
    va_start(args, template);
    int len = vsnprintf(NULL, 0, template, args);
    if (len < 0) return -1;
    va_end(args);

    *buf = malloc(len + 1);
    if (!*buf) {
        err("malloc");
        return -1;
    }
    va_start(args, template);
    vsnprintf(*buf, len + 1, template, args);
    va_end(args);

    return len;
}

void log_event(const char* buf, size_t len) {
    int fd = events_log_fd;
    if (fd < 0) {
        err("log file");
        return;
    }
    write(fd, buf, len);
}

void log_started_pid(timestamp_t timestamp, int p_number, int pid, int ppid, balance_t balance) {
    char* buf;
    int len = get_string_by_template(&buf, log_started_fmt, get_physical_time(), p_number, pid, ppid, balance);
    log_event(buf, len);
    free(buf);
}

void log_transfer_out(timestamp_t timestamp, int sender, int receiver, balance_t amount) {
    char* buf;
    int len = get_string_by_template(&buf, log_transfer_out_fmt, timestamp, sender, amount, receiver);
    log_event(buf, len);
    free(buf);
}

void log_transfer_in(timestamp_t timestamp, int sender, int receiver, balance_t amount) {
    char* buf;
    int len = get_string_by_template(&buf, log_transfer_in_fmt, timestamp, receiver, amount, sender);
    log_event(buf, len);
    free(buf);
}

void log_all_started(timestamp_t timestamp, int pid) {
    char* buf;
    int len = get_string_by_template(&buf, log_received_all_started_fmt, get_physical_time(), pid);
    log_event(buf, len);
    free(buf);
}

void log_all_done(timestamp_t timestamp, int pid) {
    char* buf;
    int len = get_string_by_template(&buf, log_received_all_done_fmt, get_physical_time(), pid);
    log_event(buf, len);
    free(buf);
}

int receive_all(void* self, int start_pid, int end_pid, uint16_t msg_type) {
    int*** pipes = (int***)self;
    int count = end_pid - start_pid + 1;
    Message msg;
    int received[count];
    memset(received, 0, sizeof(int) * count);
    int received_count = 0;

    if (PROCESS_ID >= start_pid && PROCESS_ID <= end_pid) {
        received[PROCESS_ID - start_pid] = 1;
        received_count++;
    }

    while (received_count < count) {
        for (int pid = start_pid; pid <= end_pid; pid++) {
            if (!received[pid - start_pid] && pid != PROCESS_ID) {
                if (receive(pipes, pid, &msg) == 0 && msg.s_header.s_type == msg_type) {
                    received[pid - start_pid] = 1;
                    received_count++;
                }
            }
        }
    }

    if (msg_type == STARTED) {
        log_all_started(get_physical_time(), PROCESS_ID);
    }
    else if (msg_type == DONE) {
        log_all_done(get_physical_time(), PROCESS_ID);
    }
    return 0;
}

int read_process_count(int argc, char* argv[]) {
    int opt;
    int count = 0;
    while ((opt = getopt(argc, argv, "p:")) != -1) {
        if (opt == 'p') {
            count = atoi(optarg);
            return count;
        }
    }
    return -1;
}

void get_balance_arr(int argc, char* argv[], balance_t* balances) {
    for (int i = 3; i < argc; i++) {
        balances[i - 2] = atoi(argv[i]);
    }
}

int create_pipes(int n) {
    n++;
    pipes = malloc(sizeof(int**) * n);
    if (!pipes) {
        err("malloc");
        exit(1);
    }

    for (int i = 0; i < n; i++) {
        pipes[i] = malloc(sizeof(int*) * n);
        for (int j = 0; j < n; j++) {
            if (i != j) {
                pipes[i][j] = malloc(2 * sizeof(int));
                if (pipe(pipes[i][j]) == -1) {
                    err("pipe");
                    exit(1);
                }
                fcntl(pipes[i][j][0], F_SETFL, O_NONBLOCK);
                fcntl(pipes[i][j][1], F_SETFL, O_NONBLOCK);
            }
        }
    }
    return 0;
}

void close_unused_pipes(int*** pipes) {
    for (int i = 0; i <= P_COUNT; i++) {
        for (int j = 0; j <= P_COUNT; j++) {
            if (i != j) {
                if (i == PROCESS_ID)
                    close(pipes[i][j][1]);
                if (j == PROCESS_ID)
                    close(pipes[i][j][0]);
                if (i != PROCESS_ID && j != PROCESS_ID) {
                    close(pipes[i][j][0]);
                    close(pipes[i][j][1]);
                }
            }
        }
    }
}

int free_pipes(int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i != j) {
                close(pipes[i][j][0]);
                close(pipes[i][j][1]);
            }
            free(pipes[i][j]);
        }
        free(pipes[i]);
    }
    free(pipes);
    return 0;
}

int log_pipes(int n, const char* pipes_log) {
    int log_fd = pipes_log_fd;
    char buf[128];
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i != j) {
                int len = snprintf(buf, sizeof(buf),
                    "[%d->%d: r=%d w=%d] ",
                    i, j, pipes[i][j][0], pipes[i][j][1]);
                write(log_fd, buf, len);
            }
            else {
                write(log_fd, "[X] ", 4);
            }
        }
        write(log_fd, "\n", 1);
    }
    return 0;
}
