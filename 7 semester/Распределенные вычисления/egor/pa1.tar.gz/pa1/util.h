#ifndef __IFMO_DISTRIBUTED_CLASS_UTIL__H
#define __IFMO_DISTRIBUTED_CLASS_UTIL__H
#define _POSIX_C_SOURCE 200809L

#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include "ipc.h"
#include <stdarg.h>
#include "pa1.h"
#include "time.h"
#include <sys/wait.h>
#include <errno.h>
#include "common.h"

#define MAX_PROCESSES 16
#define PIPE_READ 0
#define PIPE_WRITE 1
#define MAX_LOG_LINE 256

typedef struct {
    int process_id;
    int process_count;
    pid_t curr_pid;
    pid_t parent_pid;
    int*** pipes;
    int pipes_log_fd;
    int events_log_fd;
} ProcessContext;

extern ProcessContext ctx;

int read_process_count(int argc, char* argv[]);
int create_pipes(int process_count);
int log_pipes(int process_count);
void close_unused_pipes(void);
void free_pipes_resources(void);
int format_string(char** buf, const char* template, ...);
timestamp_t get_physical_time(void);
Message* create_message(MessageType msg_type, const char* payload, int payload_len);
int log_event_message(const char* message);
void log_error(const char* message);
int receive_all_messages(uint16_t expected_type, int expected_count);
int initialize_context(int process_count);

#endif
