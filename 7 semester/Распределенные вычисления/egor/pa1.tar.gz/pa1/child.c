#include "child.h"
#include "ipc.h"
#include "pa1.h"
#include "util.h"

static int send_process_message(MessageType msg_type, const char* template,
    ...) {
    char* formatted_msg = NULL;
    Message* message = NULL;
    va_list args;
    int result = -1;

    va_start(args, template);
    int len = vsnprintf(NULL, 0, template, args);
    va_end(args);

    if (len < 0) {
        log_error("Failed to calculate message length");
        goto cleanup;
    }

    formatted_msg = malloc(len + 1);
    if (!formatted_msg) {
        log_error("Failed to allocate message buffer");
        goto cleanup;
    }

    va_start(args, template);
    vsnprintf(formatted_msg, len + 1, template, args);
    va_end(args);

    message = create_message(msg_type, formatted_msg, len);
    if (!message) {
        log_error("Failed to create message");
        goto cleanup;
    }

    result = send_multicast(ctx.pipes, message);

cleanup:
    if (formatted_msg)
        free(formatted_msg);
    if (message)
        free(message);
    return result;
}

void child_main(void) {
    int result = 0;
    close_unused_pipes();
    result = send_process_message(STARTED, log_started_fmt, ctx.process_id,
        ctx.curr_pid, ctx.parent_pid);
    if (result != 0) {
        log_error("STARTED phase failed");
        return;
    }

    result = receive_all_messages(STARTED, ctx.process_count - 1);
    if (result != 0) {
        log_error("Failed to receive all STARTED messages");
        return;
    }

    result = send_process_message(DONE, log_done_fmt, ctx.process_id);
    if (result != 0) {
        log_error("DONE phase failed");
        return;
    }

    result = receive_all_messages(DONE, ctx.process_count - 1);
    if (result != 0) {
        log_error("Failed to receive all DONE messages");
    }
}
