#include "util.h"

ProcessContext ctx = { 0 };

int read_process_count(int argc, char* argv[])
{
    if (argc < 3) {
        fprintf(stderr, "Usage: %s -p <process_count>\n", argv[0]);
        return -1;
    }

    int opt;
    int process_count = -1;

    while ((opt = getopt(argc, argv, "p:")) != -1) {
        switch (opt) {
        case 'p':
            process_count = atoi(optarg);
            if (process_count <= 0 || process_count > MAX_PROCESSES) {
                fprintf(stderr, "Process count must be between 1 and %d\n", MAX_PROCESSES);
                return -1;
            }
            break;
        default:
            fprintf(stderr, "Usage: %s -p <process_count>\n", argv[0]);
            return -1;
        }
    }

    return process_count;
}

int initialize_context(int process_count)
{
    ctx.process_count = process_count;
    ctx.curr_pid = getpid();
    ctx.parent_pid = getppid();

    ctx.events_log_fd = open(events_log, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (ctx.events_log_fd < 0) {
        perror("Failed to open events log");
        return -1;
    }

    ctx.pipes_log_fd = open(pipes_log, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (ctx.pipes_log_fd < 0) {
        perror("Failed to open pipes log");
        close(ctx.events_log_fd);
        return -1;
    }

    return 0;
}

int create_pipes(int process_count)
{
    int total_processes = process_count + 1;

    ctx.pipes = malloc(sizeof(int**) * total_processes);
    if (!ctx.pipes) {
        log_error("Failed to allocate pipes array");
        return -1;
    }

    for (int i = 0; i < total_processes; i++) {
        ctx.pipes[i] = calloc(total_processes, sizeof(int*));
        if (!ctx.pipes[i]) {
            log_error("Failed to allocate pipe row");
            goto cleanup;
        }

        for (int j = 0; j < total_processes; j++) {
            if (i != j) {
                ctx.pipes[i][j] = malloc(2 * sizeof(int));
                if (!ctx.pipes[i][j]) {
                    log_error("Failed to allocate pipe");
                    goto cleanup;
                }

                if (pipe(ctx.pipes[i][j]) == -1) {
                    log_error("Failed to create pipe");
                    free(ctx.pipes[i][j]);
                    ctx.pipes[i][j] = NULL;
                    goto cleanup;
                }
            }
        }
    }
    return 0;

cleanup:
    free_pipes_resources();
    return -1;
}

int log_pipes(int process_count)
{
    if (ctx.pipes_log_fd < 0) return -1;

    char buffer[MAX_LOG_LINE];
    int total_processes = process_count + 1;

    for (int i = 0; i < total_processes; i++) {
        for (int j = 0; j < total_processes; j++) {
            if (i != j && ctx.pipes[i][j]) {
                int len = snprintf(buffer, sizeof(buffer),
                    "[%d->%d: r=%d w=%d] ",
                    i, j, ctx.pipes[i][j][PIPE_READ], ctx.pipes[i][j][PIPE_WRITE]);
                if (write(ctx.pipes_log_fd, buffer, len) != len) {
                    log_error("Failed to write pipe log");
                }
            }
            else {
                if (write(ctx.pipes_log_fd, "[X] ", 4) != 4) {
                    log_error("Failed to write pipe log");
                }
            }
        }
        if (write(ctx.pipes_log_fd, "\n", 1) != 1) {
            log_error("Failed to write pipe log");
        }
    }
    return 0;
}

void close_unused_pipes(void)
{
    int total_processes = ctx.process_count + 1;

    for (int i = 0; i < total_processes; i++) {
        for (int j = 0; j < total_processes; j++) {
            if (i != j && ctx.pipes[i][j]) {
                if (i == ctx.process_id) {
                    close(ctx.pipes[i][j][PIPE_WRITE]);
                }
                if (j == ctx.process_id) {
                    close(ctx.pipes[i][j][PIPE_READ]);
                }
                if (i != ctx.process_id && j != ctx.process_id) {
                    close(ctx.pipes[i][j][PIPE_READ]);
                    close(ctx.pipes[i][j][PIPE_WRITE]);
                }
            }
        }
    }
}

void free_pipes_resources(void)
{
    if (!ctx.pipes) return;

    int total_processes = ctx.process_count + 1;

    for (int i = 0; i < total_processes; i++) {
        if (ctx.pipes[i]) {
            for (int j = 0; j < total_processes; j++) {
                if (ctx.pipes[i][j]) {
                    close(ctx.pipes[i][j][PIPE_READ]);
                    close(ctx.pipes[i][j][PIPE_WRITE]);
                    free(ctx.pipes[i][j]);
                }
            }
            free(ctx.pipes[i]);
        }
    }
    free(ctx.pipes);
    ctx.pipes = NULL;

    if (ctx.events_log_fd >= 0) close(ctx.events_log_fd);
    if (ctx.pipes_log_fd >= 0) close(ctx.pipes_log_fd);
}

int format_string(char** buf, const char* template, ...)
{
    va_list args;

    va_start(args, template);
    int length = vsnprintf(NULL, 0, template, args);
    va_end(args);

    if (length < 0) return -1;

    *buf = malloc(length + 1);
    if (!*buf) {
        log_error("Failed to allocate string buffer");
        return -1;
    }

    va_start(args, template);
    vsnprintf(*buf, length + 1, template, args);
    va_end(args);

    return length;
}

timestamp_t get_physical_time(void)
{
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) == -1) {
        return 0;
    }
    return (timestamp_t)(ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
}

Message* create_message(MessageType msg_type, const char* payload, int payload_len)
{
    if (payload_len < 0 || payload_len > MAX_PAYLOAD_LEN) {
        log_error("Invalid payload length");
        return NULL;
    }

    log_event_message(payload);

    Message* message = malloc(sizeof(Message));
    if (!message) {
        log_error("Failed to allocate message");
        return NULL;
    }

    message->s_header.s_magic = MESSAGE_MAGIC;
    message->s_header.s_type = msg_type;
    message->s_header.s_local_time = get_physical_time();
    message->s_header.s_payload_len = payload_len;

    if (payload_len > 0) {
        memcpy(message->s_payload, payload, payload_len);
    }

    return message;
}

int log_event_message(const char* message)
{
    if (ctx.events_log_fd < 0) return -1;

    size_t length = strlen(message);
    ssize_t written = write(ctx.events_log_fd, message, length);

    if (written != (ssize_t)length) {
        log_error("Failed to write event log");
        return -1;
    }

    return 0;
}

void log_error(const char* message)
{
    fprintf(stderr, "ERROR: %s (errno: %d)\n", message, errno);
}

int receive_all_messages(uint16_t expected_type, int expected_count)
{
    if (!ctx.pipes || expected_count <= 0) return -1;

    Message received_msg;
    int *received_from = calloc(ctx.process_count + 1, sizeof(int));
    if (!received_from) {
        return -1;
    }

    int received_count = 0;
    int max_attempts = ctx.process_count * 100;
    int attempts = 0;

    while (received_count < expected_count && attempts < max_attempts) {
        for (int pid = 1; pid <= ctx.process_count; pid++) {
            if (pid != ctx.process_id && !received_from[pid]) {
                if (receive(ctx.pipes, pid, &received_msg) == 0) {
                    if (received_msg.s_header.s_type == expected_type) {
                        received_from[pid] = 1;
                        received_count++;
                    }
                }
            }
        }
        attempts++;
    }

    char *log_message = NULL;
    const char *template = NULL;

    switch (expected_type) {
        case STARTED:
            template = log_received_all_started_fmt;
        break;
        case DONE:
            template = log_received_all_done_fmt;
        break;
        default:
            break;
    }

    if (template) {
        int len = format_string(&log_message, template, ctx.process_id);
        if (len > 0 && log_message) {
            log_event_message(log_message);
            free(log_message);
        }
    }

    free(received_from);
    return (received_count == expected_count) ? 0 : -1;
}
