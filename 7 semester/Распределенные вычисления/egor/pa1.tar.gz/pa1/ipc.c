#include "ipc.h"
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include "util.h"

int send(void* self, local_id dst, const Message* msg)
{
    int*** pipes = (int***)self;
    int write_fd = pipes[dst][ctx.process_id][PIPE_WRITE];

    uint16_t total_msg_len = sizeof(MessageHeader) + msg->s_header.s_payload_len;
    const char* buffer = (const char*)msg;
    ssize_t total_written = 0;

    while (total_written < total_msg_len) {
        ssize_t bytes_written = write(write_fd,
            buffer + total_written,
            total_msg_len - total_written);

        if (bytes_written <= 0) {
            log_error("Sending msg error");
            return -1;
        }
        total_written += bytes_written;
    }

    return 0;
}

int send_multicast(void* self, const Message* msg)
{
    int*** pipes = (int***)self;

    for (local_id pid = 0; pid <= ctx.process_count; pid++) {
        if (pid != ctx.process_id) {
            send(pipes, pid, msg);
        }
    }

    return 0;
}

int receive(void* self, local_id from, Message* msg)
{
    int*** pipes = (int***)self;
    int read_fd = pipes[ctx.process_id][from][PIPE_READ];

    ssize_t total_read = 0;
    char* header_buffer = (char*)&msg->s_header;

    while (total_read < sizeof(MessageHeader)) {
        ssize_t bytes_read = read(read_fd,
            header_buffer + total_read,
            sizeof(MessageHeader) - total_read);

        if (bytes_read <= 0) {
            return -1;
        }
        total_read += bytes_read;
    }

    uint16_t payload_len = msg->s_header.s_payload_len;
    total_read = 0;

    while (total_read < payload_len) {
        ssize_t bytes_read = read(read_fd,
            msg->s_payload + total_read,
            payload_len - total_read);

        if (bytes_read <= 0) {
            return -1;
        }
        total_read += bytes_read;
    }

    return 0;
}

int receive_any(void* self, Message* msg)
{
    int*** pipes = (int***)self;

    for (local_id from = 0; from <= ctx.process_count; from++) {
        if (from != ctx.process_id) {
            if (receive(pipes, from, msg) == 0) {
                return 0;
            }
        }
    }

    return -1;
}
