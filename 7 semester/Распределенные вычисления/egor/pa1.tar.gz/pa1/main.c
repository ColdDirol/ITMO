#include "common.h"
#include "ipc.h"
#include "util.h"
#include "pa1.h"
#include "child.h"

int next_id = 1;

void create_child_process(int process_count)
{
    pid_t pid;
    pid = fork();
    switch (pid)
    {
    case -1:
        log_error("fork");
        exit(EXIT_FAILURE);
    case 0:
        ctx.process_id = next_id;
        ctx.curr_pid = getpid();
        ctx.parent_pid = getppid();
        child_main();
        exit(0);
    default:
        next_id++;
    }
}

void root_main(void)
{
    close_unused_pipes();
    receive_all_messages(STARTED, ctx.process_count);
    receive_all_messages(DONE, ctx.process_count);

    while (wait(NULL) > 0);
}

int main(int argc, char* argv[])
{
    int n = read_process_count(argc, argv);
    if (n < 1)
    {
        log_error("Number of processes must be positive");
        return 1;
    }

    if (initialize_context(n) != 0) {
        log_error("Failed to initialize context");
        return 1;
    }

    if (create_pipes(n) != 0) {
        log_error("Failed to create pipes");
        return 1;
    }

    if (log_pipes(n) != 0) {
        log_error("Failed to log pipes");
        return 1;
    }

    for (int i = 0; i < n; i++)
    {
        create_child_process(n);
    }

    root_main();

    free_pipes_resources();
    return 0;
}
