#ifndef __IFMO_DISTRIBUTED_CLASS_CHILD__H
#define __IFMO_DISTRIBUTED_CLASS_CHILD__H

#include <sys/types.h>
#include <unistd.h>

void child_main(void);

#endif
