#define _POSIX_C_SOURCE 200809L
#define _GNU_SOURCE
#include "banking.h"
#include "ipc.h"
#include "pa2345.h"
#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <time.h>

int pipes[16][16][2];
int local_id_g;
int proc_count;
int lamport_time = 0;

static int use_mutex = 0;
static int events_log_fd = -1;

typedef struct {
    int time;
    int id;
} QueueEntry;

static QueueEntry cs_queue[16];
static int cs_queue_size = 0;
static int cs_replies = 0;
static int done_received[16] = {0};

static void ltime_inc(void) { lamport_time++; }
static int ltime_get(void) { return lamport_time; }

static void queue_add(int t, int id) {
    cs_queue[cs_queue_size].time = t;
    cs_queue[cs_queue_size].id = id;
    cs_queue_size++;
    for (int i = cs_queue_size - 1; i > 0; i--) {
        QueueEntry a = cs_queue[i - 1], b = cs_queue[i];
        if (a.time > b.time || (a.time == b.time && a.id > b.id)) {
            cs_queue[i - 1] = b;
            cs_queue[i] = a;
        } else break;
    }
}

static void queue_remove(int id) {
    for (int i = 0; i < cs_queue_size; i++) {
        if (cs_queue[i].id == id) {
            for (int j = i; j < cs_queue_size - 1; j++)
                cs_queue[j] = cs_queue[j + 1];
            cs_queue_size--;
            return;
        }
    }
}

static int queue_first(void) {
    return cs_queue_size > 0 && cs_queue[0].id == local_id_g;
}

static void send_msg(int to, MessageType type) {
    Message msg;
    ltime_inc();
    msg.s_header.s_magic = MESSAGE_MAGIC;
    msg.s_header.s_payload_len = 0;
    msg.s_header.s_type = type;
    msg.s_header.s_local_time = (timestamp_t)ltime_get();
    send(NULL, to, &msg);
}

int request_cs(const void * self) {
    (void)self;
    ltime_inc();
    int req_time = ltime_get();
    queue_add(req_time, local_id_g);
    cs_replies = 0;

    Message req_msg;
    req_msg.s_header.s_magic = MESSAGE_MAGIC;
    req_msg.s_header.s_payload_len = 0;
    req_msg.s_header.s_type = CS_REQUEST;
    req_msg.s_header.s_local_time = (timestamp_t)req_time;
    send_multicast(NULL, &req_msg);

    cs_replies = 0;
    for (int i = 1; i <= proc_count; i++) {
        if (i != local_id_g && done_received[i]) cs_replies++;
    }
    int need = proc_count - 1;
    struct timespec ts = {0, 1000000};
    while (cs_replies < need || !queue_first()) {
        int progress = 0;
        for (int from = 1; from <= proc_count; from++) {
            if (from == local_id_g) continue;
            if (done_received[from]) continue;
            Message in;
            if (receive(NULL, from, &in) == 0) {
                progress = 1;
                if (in.s_header.s_type == CS_REQUEST) {
                    queue_add(in.s_header.s_local_time, from);
                    send_msg(from, CS_REPLY);
                } else if (in.s_header.s_type == CS_REPLY) {
                    cs_replies++;
                } else if (in.s_header.s_type == CS_RELEASE) {
                    queue_remove(from);
                } else if (in.s_header.s_type == DONE) {
                    done_received[from] = 1;
                    cs_replies++;
                }
            }
        }
        if (!progress) nanosleep(&ts, NULL);
    }
    return 0;
}

int release_cs(const void * self) {
    (void)self;
    queue_remove(local_id_g);
    for (int i = 1; i <= proc_count; i++) {
        if (i == local_id_g) continue;
        send_msg(i, CS_RELEASE);
    }
    return 0;
}

void transfer(void * parent_data, local_id src, local_id dst, balance_t amount) {
    (void)parent_data; (void)src; (void)dst; (void)amount;
}

static void close_unused_pipes(void) {
    for (int i = 0; i <= proc_count; i++) {
        for (int j = 0; j <= proc_count; j++) {
            if (i == j) continue;
            if (i == local_id_g) {
                if (pipes[i][j][0] >= 0) {
                    close(pipes[i][j][0]);
                    pipes[i][j][0] = -1;
                }
            } else if (j == local_id_g) {
                if (pipes[i][j][1] >= 0) {
                    close(pipes[i][j][1]);
                    pipes[i][j][1] = -1;
                }
            } else {
                if (pipes[i][j][0] >= 0) {
                    close(pipes[i][j][0]);
                    pipes[i][j][0] = -1;
                }
                if (pipes[i][j][1] >= 0) {
                    close(pipes[i][j][1]);
                    pipes[i][j][1] = -1;
                }
            }
        }
    }
}

static void log_event(const char *buf) {
    if (events_log_fd != -1) {
        write(events_log_fd, buf, strlen(buf));
    }
}

static void child_process(void) {
    char buf[256];
    Message msg;

    ltime_inc();
    snprintf(buf, sizeof(buf), log_started_fmt,
             ltime_get(), local_id_g, getpid(), getppid(), 0);
    msg.s_header.s_magic = MESSAGE_MAGIC;
    msg.s_header.s_type = STARTED;
    msg.s_header.s_local_time = (timestamp_t)ltime_get();
    msg.s_header.s_payload_len = (uint16_t)strlen(buf);
    memcpy(msg.s_payload, buf, strlen(buf));
    send_multicast(NULL, &msg);

    log_event(buf);

    int started_count = 0;
    struct timespec ts = {0, 1000000};
    while (started_count < proc_count - 1) {
        int progress = 0;
        for (int from = 1; from <= proc_count; from++) {
            if (from == local_id_g) continue;
            Message in;
            if (receive(NULL, from, &in) == 0) {
                progress = 1;
                if (in.s_header.s_type == STARTED) started_count++;
                else if (in.s_header.s_type == CS_REQUEST) {
                    queue_add(in.s_header.s_local_time, from);
                    send_msg(from, CS_REPLY);
                } else if (in.s_header.s_type == CS_RELEASE) {
                    queue_remove(from);
                }
            }
        }
        if (!progress) nanosleep(&ts, NULL);
    }

    snprintf(buf, sizeof(buf), log_received_all_started_fmt, ltime_get(), local_id_g);
    log_event(buf);

    int iters = local_id_g * 5;
    for (int i = 1; i <= iters; i++) {
        if (use_mutex) request_cs(NULL);
        snprintf(buf, sizeof(buf), log_loop_operation_fmt, local_id_g, i, iters);
        print(buf);
        if (use_mutex) release_cs(NULL);
    }

    ltime_inc();
    snprintf(buf, sizeof(buf), log_done_fmt, ltime_get(), local_id_g, 0);
    msg.s_header.s_magic = MESSAGE_MAGIC;
    msg.s_header.s_type = DONE;
    msg.s_header.s_local_time = (timestamp_t)ltime_get();
    msg.s_header.s_payload_len = (uint16_t)strlen(buf);
    memcpy(msg.s_payload, buf, strlen(buf));
    send_multicast(NULL, &msg);

    log_event(buf);

    int done_count = 0;
    for (int i = 1; i <= proc_count; i++) {
        if (i != local_id_g && done_received[i]) done_count++;
    }
    while (done_count < proc_count - 1) {
        int progress = 0;
        for (int from = 1; from <= proc_count; from++) {
            if (from == local_id_g) continue;
            Message in;
            if (receive(NULL, from, &in) == 0) {
                progress = 1;
                if (in.s_header.s_type == DONE) {
                    if (!done_received[from]) {
                        done_received[from] = 1;
                        done_count++;
                    }
                } else if (in.s_header.s_type == CS_REQUEST) {
                    send_msg(from, CS_REPLY);
                } else if (in.s_header.s_type == CS_RELEASE) {
                    queue_remove(from);
                }
            }
        }
        if (!progress) nanosleep(&ts, NULL);
    }

    snprintf(buf, sizeof(buf), log_received_all_done_fmt, ltime_get(), local_id_g);
    log_event(buf);
}

static void parent_process(void) {
    Message msg;
    char buf[256];

    int started_count = 0;
    int done_count = 0;
    int logged_started = 0;
    while (started_count < proc_count || done_count < proc_count) {
        receive_any(NULL, &msg);
        if (msg.s_header.s_type == STARTED) started_count++;
        else if (msg.s_header.s_type == DONE) done_count++;
        if (started_count >= proc_count && !logged_started) {
            logged_started = 1;
            snprintf(buf, sizeof(buf), log_received_all_started_fmt, ltime_get(), local_id_g);
            log_event(buf);
        }
    }

    snprintf(buf, sizeof(buf), log_received_all_done_fmt, ltime_get(), local_id_g);
    log_event(buf);
}

int main(int argc, char *argv[]) {
    int n = 0;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--mutexl") == 0) use_mutex = 1;
        else if (strcmp(argv[i], "-p") == 0 && i + 1 < argc) n = atoi(argv[++i]);
    }

    if (n <= 0 || n > 15) return 1;

    proc_count = n;
    local_id_g = PARENT_ID;

    for (int i = 0; i < 16; i++)
        for (int j = 0; j < 16; j++)
            pipes[i][j][0] = pipes[i][j][1] = -1;

    events_log_fd = open(events_log, O_WRONLY | O_CREAT | O_APPEND | O_TRUNC, 0644);
    if (events_log_fd == -1) return 1;

    FILE *plog = fopen(pipes_log, "w");
    if (plog) fclose(plog);

    for (int i = 0; i <= proc_count; i++) {
        for (int j = 0; j <= proc_count; j++) {
            if (i == j) continue;
            if (pipe(pipes[i][j]) == -1) return 1;
            fcntl(pipes[i][j][0], F_SETFL, O_NONBLOCK);
            fcntl(pipes[i][j][1], F_SETFL, O_NONBLOCK);
        }
    }

    for (int i = 1; i <= proc_count; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            local_id_g = i;
            lamport_time = 0;
            cs_queue_size = 0;
            cs_replies = 0;
            memset(done_received, 0, sizeof(done_received));
            close_unused_pipes();
            child_process();
            exit(0);
        }
    }

    close_unused_pipes();
    parent_process();

    for (int i = 0; i < proc_count; i++) wait(NULL);

    close(events_log_fd);
    return 0;
}
