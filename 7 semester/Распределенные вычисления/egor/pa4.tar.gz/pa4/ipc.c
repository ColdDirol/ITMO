#define _POSIX_C_SOURCE 199309L
#include "ipc.h"
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <fcntl.h>

extern int pipes[16][16][2];
extern int local_id_g;
extern int proc_count;
extern int lamport_time;

int send(void * self, local_id dst, const Message * msg) {
    (void)self;
    int fd = pipes[local_id_g][dst][1];
    if (fd < 0) return -1;
    size_t total = sizeof(MessageHeader) + msg->s_header.s_payload_len;
    const char *ptr = (const char *)msg;
    size_t left = total;
    while (left > 0) {
        ssize_t w = write(fd, ptr, left);
        if (w > 0) { ptr += w; left -= w; }
        else if (w == -1 && errno == EAGAIN) continue;
        else return -1;
    }
    return 0;
}

int send_multicast(void * self, const Message * msg) {
    for (int i = 0; i <= proc_count; i++) {
        if (i == local_id_g) continue;
        if (send(self, i, msg) != 0) return -1;
    }
    return 0;
}

static int recv_from(int from, Message * msg) {
    int fd = pipes[from][local_id_g][0];
    if (fd < 0) return -1;
    int avail = 0;
    if (ioctl(fd, FIONREAD, &avail) == -1) return -1;
    if (avail < (int)sizeof(MessageHeader)) return -1;
    ssize_t r = read(fd, &msg->s_header, sizeof(MessageHeader));
    if (r != (ssize_t)sizeof(MessageHeader)) return -1;
    if (msg->s_header.s_payload_len > 0) {
        char *p = msg->s_payload;
        size_t left = msg->s_header.s_payload_len;
        while (left > 0) {
            ssize_t pr = read(fd, p, left);
            if (pr > 0) { p += pr; left -= pr; }
            else if (pr == -1 && errno == EAGAIN) continue;
            else return -1;
        }
    }
    if (msg->s_header.s_local_time > lamport_time)
        lamport_time = msg->s_header.s_local_time;
    lamport_time++;
    return 0;
}

int receive(void * self, local_id from, Message * msg) {
    (void)self;
    return recv_from(from, msg);
}

int receive_any(void * self, Message * msg) {
    (void)self;
    struct timespec ts = {0, 1000000};
    while (1) {
        for (int from = 0; from <= proc_count; from++) {
            if (from == local_id_g) continue;
            if (recv_from(from, msg) == 0) return 0;
        }
        nanosleep(&ts, NULL);
    }
}
